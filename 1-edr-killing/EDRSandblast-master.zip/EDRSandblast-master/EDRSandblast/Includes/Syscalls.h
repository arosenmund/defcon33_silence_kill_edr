#pragma once
#include <Windows.h>

PVOID CreateSyscallStubWithVirtuallAlloc(LPCSTR ntFunctionName);