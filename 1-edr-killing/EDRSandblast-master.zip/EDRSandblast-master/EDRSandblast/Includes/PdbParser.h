#pragma once
#include <Windows.h>

PVOID extractGuidFromPdb(LPWSTR filepath);