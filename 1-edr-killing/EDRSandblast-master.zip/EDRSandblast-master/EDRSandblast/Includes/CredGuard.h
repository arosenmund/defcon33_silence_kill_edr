#pragma once

#include <Windows.h>

DWORD WINAPI disableCredGuardByPatchingLSASS(void);
