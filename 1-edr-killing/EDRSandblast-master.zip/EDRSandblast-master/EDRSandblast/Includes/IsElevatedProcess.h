#pragma once

#include "Windows.h"
#include "Tchar.h"

#pragma comment(lib, "netapi32.lib")

BOOL IsElevatedProcess();